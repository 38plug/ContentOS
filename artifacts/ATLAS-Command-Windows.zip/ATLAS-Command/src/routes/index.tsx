import { createFileRoute, Link } from "@tanstack/react-router";
import { CrewBoard } from "@/components/crew-board";
import { JarvisChat } from "@/components/jarvis-chat";
import { Metrics } from "@/components/metric";
import { NeuronMap } from "@/components/neuron-map";
import { Shell } from "@/components/shell";
import { cashOf, useConsole } from "@/lib/console-store";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  const finance = useConsole((s) => s.finance);
  const jobs = useConsole((s) => s.jobs);
  const candidates = useConsole((s) => s.candidates);
  const interviews = useConsole((s) => s.interviews);
  const tasks = useConsole((s) => s.tasks);
  const cash = cashOf(finance);
  const income = finance.filter((e) => e.type === "income").reduce((n, e) => n + e.amount, 0);
  const expense = finance.filter((e) => e.type === "expense").reduce((n, e) => n + e.amount, 0);
  const openTasks = tasks.filter((t) => t.status !== "done").length;

  return (
    <Shell title="Good morning, Plug" eyebrow="Tuesday, 1 Sep 2026 · ICT" scope="atlas">
      <Metrics
        items={[
          { label: "Qrrupt cash", value: `$${cash}`, detail: `in $${income} / out $${expense}` },
          { label: "Active jobs", value: String(jobs.filter((j) => j.status === "Active").length), detail: "HireFlow" },
          { label: "Candidates", value: String(candidates.length), detail: "desk + telegram intake" },
          { label: "Open tasks", value: String(openTasks), detail: `${interviews.length} interviews on book` },
        ]}
      />

      <div className="grid lg:grid-cols-[1.15fr_0.85fr] gap-4 mt-4">
        <JarvisChat />
        <div className="rounded-lg border border-line bg-surface p-4">
          <h2 className="text-sm font-semibold">Needs you</h2>
          <ul className="mt-3 space-y-3 text-sm">
            <li className="text-muted">Kenji Sato interview still pending confirmation.</li>
            <li className="text-muted">ETH live-track task is still todo on Qrrupt.</li>
            <li className="text-muted">Chinese finance system is in progress — CODER can pick it up.</li>
          </ul>
          <div className="flex flex-wrap gap-2 mt-5">
            <Link to="/hireflow" className="min-h-11 px-4 grid place-items-center rounded-md bg-elevated text-sm border border-line">
              Open HireFlow
            </Link>
            <Link to="/qrrupt" className="min-h-11 px-4 grid place-items-center rounded-md bg-elevated text-sm border border-line">
              Open Qrrupt
            </Link>
          </div>
        </div>
      </div>

      <div className="mt-4">
        <NeuronMap />
      </div>

      <div className="mt-6">
        <div className="flex items-center justify-between mb-3">
          <h2 className="text-sm font-semibold">Crew</h2>
          <Link to="/crew" className="text-xs text-accent">
            Manage tasks
          </Link>
        </div>
        <CrewBoard compact />
      </div>
    </Shell>
  );
}
