@echo off
title ATLAS
cd /d "%~dp0"
if exist "package.json" goto :run
cd /d "%~dp0\.."
:run
echo ========================================
echo   ATLAS  —  HireFlow + Qrrupt command
echo ========================================
echo.

where node >nul 2>nul
if errorlevel 1 (
  echo Node.js is not installed.
  echo Open https://nodejs.org  — install LTS, tick Add to PATH.
  start https://nodejs.org
  pause
  exit /b 1
)

if not exist "node_modules\" (
  echo First launch — installing packages...
  call npm install
  if errorlevel 1 (
    echo npm install failed.
    pause
    exit /b 1
  )
)

echo Starting ATLAS...
start "" http://127.0.0.1:8080/
call npx --yes vite dev --host 0.0.0.0 --port 8080
pause
