import { Send } from "lucide-react";
import { useMemo, useState } from "react";
import { cashOf, useConsole } from "@/lib/console-store";
import { askJarvis } from "@/lib/ask-jarvis";
import { runLocalIntent } from "@/lib/local-intent";

export function JarvisChat() {
  const chat = useConsole((s) => s.chat);
  const pushChat = useConsole((s) => s.pushChat);
  const operator = useConsole((s) => s.operator);
  const currency = useConsole((s) => s.currency);
  const finance = useConsole((s) => s.finance);
  const jobs = useConsole((s) => s.jobs);
  const candidates = useConsole((s) => s.candidates);
  const interviews = useConsole((s) => s.interviews);
  const tasks = useConsole((s) => s.tasks);
  const snapshot = useMemo(
    () => ({
      operator,
      currency,
      cash: cashOf(finance),
      income: finance.filter((e) => e.type === "income").reduce((n, e) => n + e.amount, 0),
      expense: finance.filter((e) => e.type === "expense").reduce((n, e) => n + e.amount, 0),
      openJobs: jobs.filter((j) => j.status === "Active").length,
      candidates: candidates.length,
      interviewsToday: interviews.map((i) => `${i.time} ${i.candidate} (${i.status})`),
      hireflowTasks: tasks.filter((t) => t.company === "hireflow" && t.status !== "done").map((t) => t.title),
      qrruptTasks: tasks.filter((t) => t.company === "qrrupt" && t.status !== "done").map((t) => t.title),
      lastFinance: finance.slice(0, 4).map((e) => `${e.type} ${e.amount} ${e.description}`),
    }),
    [operator, currency, finance, jobs, candidates, interviews, tasks],
  );
  const [text, setText] = useState("");
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");

  async function send() {
    const message = text.trim();
    if (!message || busy) return;
    setText("");
    setErr("");
    pushChat({ role: "user", text: message, agent: "jarvis" });
    const local = runLocalIntent(message);
    if (local) {
      pushChat({ role: "assistant", text: local.reply, agent: local.agent });
      return;
    }
    setBusy(true);
    try {
      const res = await askJarvis({ data: { message, snapshot } });
      if (!res.ok) {
        setErr(res.error);
        pushChat({
          role: "assistant",
          agent: "jarvis",
          text: "I could not reach the model. Try “brief”, “cash”, “add expense 40 ads”, or “add candidate Ana”.",
        });
      } else {
        pushChat({ role: "assistant", text: res.text, agent: "jarvis" });
      }
    } catch {
      setErr("Network error");
      pushChat({
        role: "assistant",
        agent: "jarvis",
        text: "Offline. Local commands still work: brief · cash · add expense 40 ads · add candidate Ana.",
      });
    } finally {
      setBusy(false);
    }
  }

  return (
    <section className="rounded-lg border border-line bg-surface flex flex-col min-h-80">
      <div className="px-4 py-3 border-b border-line">
        <h2 className="text-sm font-semibold">JARVIS</h2>
        <p className="text-xs text-muted mt-0.5">Chief of staff · dual desk</p>
      </div>
      <div className="flex-1 overflow-y-auto p-4 space-y-3 max-h-80">
        {chat.map((m) => (
          <div key={m.id} className={m.role === "user" ? "text-right" : "text-left"}>
            <div
              className={
                m.role === "user"
                  ? "inline-block max-w-[90%] rounded-md bg-elevated px-3 py-2 text-sm"
                  : "inline-block max-w-[90%] rounded-md bg-accent-dim px-3 py-2 text-sm text-fg"
              }
            >
              {m.role === "assistant" ? (
                <div className="text-[10px] uppercase tracking-wider text-accent mb-1">{m.agent}</div>
              ) : null}
              <p className="leading-relaxed whitespace-pre-wrap">{m.text}</p>
            </div>
          </div>
        ))}
      </div>
      <form
        className="flex gap-2 p-3 border-t border-line"
        onSubmit={(e) => {
          e.preventDefault();
          void send();
        }}
      >
        <input
          className="flex-1 min-h-11 rounded-md bg-bg border border-line px-3 text-sm text-fg outline-none focus:border-accent"
          placeholder="brief · cash · add expense 40 ads · ask anything"
          value={text}
          onChange={(e) => setText(e.target.value)}
        />
        <button
          type="submit"
          disabled={busy}
          className="size-11 grid place-items-center rounded-md bg-accent text-bg disabled:opacity-50"
          aria-label="Send"
        >
          <Send className="size-4" />
        </button>
      </form>
      {err ? <p className="px-3 pb-3 text-xs text-danger">{err}</p> : null}
    </section>
  );
}
