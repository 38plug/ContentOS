ATLAS — HireFlow + Qrrupt command
=================================

Windows

1. Unzip this folder. Do not run ATLAS.exe from inside the zip.
2. Double-click ATLAS.exe  (or LAUNCH.bat if Windows blocks the exe).
3. First launch installs packages (needs internet, a few minutes).
4. Your browser opens the command center.
5. Leave the black window open while you work. Close it to stop.

Requires Node.js LTS from https://nodejs.org  (tick "Add to PATH").

If Windows SmartScreen says "Windows protected your PC":
  More info → Run anyway. The exe only starts Node in this folder.

What you get
- Command  : JARVIS, learning graph, crew
- HireFlow : jobs, candidates, pipeline, register
- Qrrupt   : ledger, cash, calendar, tasks

Data stays in this browser (local). It is not uploaded.

JARVIS local commands (no extra keys):
  brief
  cash
  add expense 40 ads
  add candidate Ana

Optional: to let JARVIS talk with Grok, set a user environment variable
XAI_API_KEY to your xAI key, then launch again.
