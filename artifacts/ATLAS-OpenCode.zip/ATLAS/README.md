# ATLAS — HireFlow + Qrrupt command

Dual-desk console for Plug.

- **HireFlow** — jobs, candidates, pipeline, interviews, employers, register
- **Qrrupt** — ledger, cash, calendar, tasks (seeded from the 31 Aug backup)
- **JARVIS** — chat + voice HUD, local commands, Grok when `XAI_API_KEY` is set
- **Crew** — HF-OPS, QR-LEDGER, MUSE, CODER, SCOUT

Data lives in the browser (`localStorage`). Wallets and login hashes are not in this repo.

## OpenCode / local

Needs **Node.js 20+** ([nodejs.org](https://nodejs.org) LTS).

```bash
npm install
npm run dev
```

Then open the URL Vite prints (default port 8080).

### Live Grok replies (optional)

Set an environment variable before `npm run dev`:

```bash
# Windows PowerShell
$env:XAI_API_KEY = "xai-..."

# macOS / Linux
export XAI_API_KEY=xai-...
```

Without a key, JARVIS still answers from the local core (`brief`, `cash`, `add expense 40 ads`, `add candidate Ana`, greetings, fallback). Voice uses the browser speech engine unless TTS is available.

## Layout

```
src/routes/index.tsx          Command
src/routes/voice.tsx          Voice HUD
src/routes/crew.tsx           Sub-agents
src/routes/hireflow/          Agency desk
src/routes/qrrupt/            Finance desk
src/lib/console-store.ts      Zustand + persist
src/lib/ask-jarvis.ts         Grok chat + TTS
src/lib/local-intent.ts       Offline commands
```

Continue in OpenCode from the project root after unzip.
