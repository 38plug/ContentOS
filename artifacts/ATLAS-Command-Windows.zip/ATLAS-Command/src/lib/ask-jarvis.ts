import { createServerFn } from "@tanstack/react-start";

export type JarvisSnapshot = {
  operator: string;
  currency: string;
  cash: number;
  income: number;
  expense: number;
  openJobs: number;
  candidates: number;
  interviewsToday: string[];
  hireflowTasks: string[];
  qrruptTasks: string[];
  lastFinance: string[];
};

export const askJarvis = createServerFn({ method: "POST" })
  .validator((input: { message: string; snapshot: JarvisSnapshot }) => input)
  .handler(async ({ data }) => {
    const apiKey = process.env.XAI_API_KEY;
    if (!apiKey) return { ok: false as const, error: "AI is not available" };

    const s = data.snapshot;
    const system = `You are JARVIS, chief of staff for Plug. Two isolated companies:
HIREFLOW = recruitment agency (jobs, candidates, interviews, employers, Telegram intake).
QRRUPT = clothing / holding finance console (cash, income, expense, paydays, tasks).
Never mix candidate names into Qrrupt money talk, or bank figures into client mail.
Voice: short, dry, precise. Address Plug. No emoji. No corporate filler.
If a specialist should own it, say which: HF-OPS, HF-FRONT, QR-LEDGER, QR-OPS, MUSE, CODER, SCOUT.
GO required: paying anyone, sending client mail, production deploy.
Snapshot:
- cash ${s.currency}${s.cash} (in ${s.income} / out ${s.expense})
- HireFlow: ${s.openJobs} jobs, ${s.candidates} candidates
- Interviews: ${s.interviewsToday.join("; ") || "none listed"}
- HF tasks: ${s.hireflowTasks.join("; ") || "none"}
- QR tasks: ${s.qrruptTasks.join("; ") || "none"}
- Recent books: ${s.lastFinance.join("; ") || "none"}
Answer in under 160 words. If you need a GO, say GO?`;

    const res = await fetch("https://api.x.ai/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model: "grok-4.5",
        max_tokens: 420,
        messages: [
          { role: "system", content: system },
          { role: "user", content: data.message.slice(0, 2000) },
        ],
      }),
    });
    if (!res.ok) return { ok: false as const, error: `xAI API error ${res.status}` };
    const body = (await res.json()) as { choices: { message: { content: string } }[] };
    return { ok: true as const, text: body.choices[0]?.message.content ?? "" };
  });
